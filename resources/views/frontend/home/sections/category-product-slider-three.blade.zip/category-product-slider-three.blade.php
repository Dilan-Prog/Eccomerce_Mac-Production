<section id="wsus__electronic2">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="wsus__section_header">
                    {{-- Hacer dinamico --}}
                    <h3>Lo más Nuevo</h3>
                    
                </div>
            </div>
        </div>
        <div class="row" id="wsus__slider-three">
            @foreach ($categoryProductsSectionsThree as $product)
                <div class="col-xl-3 col-sm-6 col-lg-4">
                    <div class="wsus__product_item">
                        <span>
                            @switch($product->product_type)
                                @case('new_arrival')
                                    <span class="wsus__new">Nuevo 
                                    </span>
                                    @break
                                @case('featured_product')
                                    <span class="wsus__new">Favorito  
                                       
                                    </span>
                                    @break                           
                                @case('top_product')
                                    <span class="wsus__new">Top  
                                        
                                    </span>
                                    @break
                                @case('best_product')
                                    <span class="wsus__new">Mas Vendido  
                                        
                                    </span>
                                    @break
                                @default
                                
                            @endswitch
                        </span>
                        
                        <a class="wsus__pro_link" href="{{route('product-detail', $product->slug)}}">
                            <img src="{{asset($product->thumb_image)}}" alt="product" class="img_1" loading="lazy" />
                            <img src="
                            @if (isset($product->productImageGalleries[0]->image))
                                {{asset($product->productImageGalleries[0]->image)}}
                            @else
                                {{asset($product->thumb_image)}}
                            @endif
                            " class="img_2" loading="lazy" />
                        </a>
                        <div class="wsus__product_details">
                            <a class="wsus__category" href="{{route('product-detail', $product->slug)}}">{{$product->category->name}}</a>
                            <p class="wsus__pro_rating">
                                @if ($product->price)

                                        @if ($product->qty > 0)
                                        <p class="wsus__stock_area"><span class="in_stock">Disponibles</span></p>
                                        @elseif ($product->qty === 0)
                                        <p class="wsus__stock_area"><span class="in_stock">Agotado</span></p>
                                        @endif

                                        <a class="wsus__pro_name" href="{{route('product-detail', $product->slug)}}">{{$product->name}}</a>
                                    @if (checkDiscount($product))
                                    <p class="wsus__price" content="{{$settings->currency_icon}}{{$product->offert_price}} MXN <del>{{$settings->currency_icon}}{{$product->price}} MXN</del>" >{{$settings->currency_icon}}{{$product->offert_price}} MXN <del>{{$settings->currency_icon}}{{$product->price}} MXN</del></p>
                                    @else
                                    <p class="wsus__price" content="{{$settings->currency_icon}}{{ number_format($product->price, 2, '.', ',') }} MXN" >{{$settings->currency_icon}}{{ number_format($product->price, 2, '.', ',') }} MXN</p>
                                    @endif

                                    @else
                                    <p class="wsus__stock_area"><span class="in_stock">Disponible</span></p>
                                    <a class="wsus__pro_name" href="{{route('product-detail', $product->slug)}}">{{$product->name}}</a>

                                    <p class="wsus__price">N/A +<small> Requiere Asesoria</small> </p>
                                    @endif
                            
                            <form class="shopping-cart-form">
                                <input type="hidden" name="product_id" value="{{$product->id}}">
                                <input type="hidden" name="brand_name" value="{{ $product->brand->name }}">
                                <input type="hidden" name="sku" value="{{$product->sku}}">
                                <input type="hidden" name="productModel" value="{{$product->productModel}}">
                                @if ($product->price)
                                    <button type="submit" class="add_cart" href="#">Agregar al Carrito</button>
                                @else
                                    <a class="add_cart2" href="{{route('contact')}}">Requiere Asesoria</a>
                                @endif
    
                                <input name="qty" type="hidden" min="1" max="100" value="1" />
                            </form>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>