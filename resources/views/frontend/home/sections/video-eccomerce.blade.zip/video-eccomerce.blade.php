<section id="video-eccomerce">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-md-6">
                <div class="content-eccomerce-information">
                    <h3>¿Comó comprar en macdelnorte.com?</h3>
                    <p>Aqui te dejamos un peque&ntilde;o video guiandote paso a paso de como comprar a traves de nuestro
                        sitio Web.
                    </p>
                    <p><b>¿Preguntas y Dudas?</b></p>
                    <p>Contactanos via whatsapp o por correo electronico te atenderemos a la brevedad para ayudarte a
                        concretar tu compra.</p>
                    <div class="d-flex mt-1">
                        <button class="common_btn mr-2"><a href="{{ route('contact') }}" target="_black"
                                style="text-decoration: none; color:white">Contacto Directo <i
                                    class="fa fa-envelope"></i></a></button>
                        <p style="margin-left: 10px; margin-right: 10px;"> o </p>
                        <button class="common_btn"><a href="https://wa.link/f28njw" target="_black"
                                style="text-decoration: none; color:white"><i class="fa fa-whatsapp"></i> Llamanos al
                                81-35825559 </a></button>
                    </div>


                </div>

            </div>
            <div class="col-xl-6 col-md-6">
                <div class="iframe-video-eccomerce">
                    <iframe src="https://www.youtube.com/embed/3w3xq8VJQSc?si=45jgHxKR5TKx-AN0"
                        title="YouTube video player" frameborder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        referrerpolicy="strict-origin-when-cross-origin" allowfullscreen loading="lazy"></iframe>
                </div>
            </div>

        </div>
</section>
