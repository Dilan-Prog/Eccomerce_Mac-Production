<?php

namespace App\DataTables;

use App\Models\AspelSync;
use App\Models\Product;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder as HtmlBuilder;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\Editor\Editor;
use Yajra\DataTables\Html\Editor\Fields;
use Yajra\DataTables\Services\DataTable;

class AspelSyncDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param QueryBuilder $query Results from query() method.
     * @return \Yajra\DataTables\EloquentDataTable
     */
    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        return (new EloquentDataTable($query))
            ->addColumn('product_name', fn($q) => $q->name)
            ->addColumn('product_productModel', fn($q) => $q->productModel)
            ->addColumn('product_sku', fn($q) => $q->sku)
            ->addColumn('product_price', fn($q) => $q->price)
            ->addColumn('product_stock', fn($q) => $q->qty)

            // Datos que vienen de aspel_products
            ->addColumn('aspel_price', fn($q) => $q->aspel_price)
            ->addColumn('aspel_stock', fn($q) => $q->aspel_stock)
            // ->addColumn('aspel_remote_update', fn($q) => $q->remote_updated_at)
            // ->addColumn('aspel_hash', fn($q) => $q->sync_hash)
            ->filter(function ($query) {
            $search = request()->input('search.value');
            if ($search) {
                $query->where(function ($q) use ($search) {
                    $q->where('products.name', 'like', "%{$search}%")
                      ->orWhere('products.sku', 'like', "%{$search}%")
                      ->orWhere('products.price', 'like', "%{$search}%");
                });
            }
        })

            ->setRowId('id');
    }

    /**
     * Get query source of dataTable.
     *
     * @param \App\Models\AspelSync $model
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query(Product $model): QueryBuilder
    {
        return $model->newQuery()
            ->leftJoin('aspel_products', 'aspel_products.sku', '=', 'products.sku')
            ->select([
                'products.*',
                'aspel_products.price as aspel_price',
                'aspel_products.stock as aspel_stock',
                'aspel_products.remote_updated_at',
                'aspel_products.sync_hash'
            ]);
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html(): HtmlBuilder
    {
        return $this->builder()
                    ->setTableId('aspelsync-table')
                    ->columns($this->getColumns())
                    ->minifiedAjax()
                    //->dom('Bfrtip')
                    ->orderBy(1)
                    ->selectStyleSingle()
                    ->buttons([
                        Button::make('excel'),
                        Button::make('csv'),
                        Button::make('pdf'),
                        Button::make('print'),
                        Button::make('reset'),
                        Button::make('reload')
                    ]);
    }

    /**
     * Get the dataTable columns definition.
     *
     * @return array
     */
    public function getColumns(): array
    {
        return [
            Column::make('product_name')->title('Producto'),
            Column::make('product_productModel')->title('Modelo'),
            Column::make('product_sku')->title('SKU'),
            Column::make('product_price')->title('Precio Web'),
            Column::make('product_stock')->title('Stock Web'),

            Column::make('aspel_price')->title('Precio Aspel'),
            Column::make('aspel_stock')->title('Stock Aspel'),
            // Column::make('aspel_remote_update')->title('Última Sync'),
            // Column::make('aspel_hash')->title('Hash Sync'),
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename(): string
    {
        return 'AspelSync_' . date('YmdHis');
    }
}
