<?php

namespace App\Http\Controllers\AspelSync;

use App\DataTables\AspelSyncDataTable;
use App\Http\Controllers\Controller;
use App\Models\AspelSync;
use Illuminate\Support\Facades\Log;

use Illuminate\Http\Request;

class AspelSyncController extends Controller
{
    // Fuction to sync data From Aspel to Local Database (firebird)
    public function sync(Request $request)
    {
        $request->validate([
            'items' => 'required|array',
            'items.*.sku' => 'required|string',
            'items.*.nombre' => 'nullable|string',
            'items.*.price' => 'required|numeric',
            'items.*.stock' => 'required|numeric'
        ]);

        foreach ($request->items as $item) {
            AspelSync::updateOrCreate(   // ← MODELO CORRECTO
                ['sku' => $item['sku']],
                [
                    'nombre' => $item['nombre'] ?? null,
                    'price'  => $item['price'],
                    'stock'  => $item['stock'],
                    'sync_hash' => md5($item['sku'].$item['price'].$item['stock'])
                ]
            );
        }

        return response()->json([
            'status' => 'OK',
            'received' => $request->all()
        ]);
    }

    public function index(AspelSyncDataTable $dataTable){

        return $dataTable->render('admin.product.sync-aspel.index');
    }


}
